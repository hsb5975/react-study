import React,{Component} from 'react';

import './services.css';

class Services extends Component{
  render(){
    return(
      <div className="services">
        <h3>Service</h3>
        <h2>What we offer</h2>
        <div className="row">
          <div>
            <span><ion-icon ios="ios-phone-portrait" md="md-phone-portrait"></ion-icon></span>
            <h4>AAA</h4>
            <p>aaaaa</p>
          </div>
          <div>
            <span><ion-icon ios="ios-phone-portrait" md="md-phone-portrait"></ion-icon></span>
            <h4>AAA</h4>
            <p>aaaaa</p>
          </div>
          <div>
            <span><ion-icon ios="ios-phone-portrait" md="md-phone-portrait"></ion-icon></span>
            <h4>AAA</h4>
            <p>aaaaa</p>
          </div>
          <div>
            <span><ion-icon ios="ios-phone-portrait" md="md-phone-portrait"></ion-icon></span>
            <h4>AAA</h4>
            <p>aaaaa</p>
          </div>
        </div>
      </div>
    );
  }
}


export default Services;
