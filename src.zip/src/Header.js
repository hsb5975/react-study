import React, {Component} from 'react';
import Background from './img/img-1-1200x1000.jpg';

import './Header.css'

const myStyles = {
  backgroundImage : 'url(' + Background + ')',
  height:'55vh',
  width:'100%',
  backgroundSize:'cover'
}

class Header extends Component{

  render(){
    return (
      <header style={ myStyles }>
        <h1>{this.props.title}</h1>
        <p >{this.props.subtitle}</p>
        <a href="#button">{this.props.button}</a>
      </header>
    );
  }
}

export default Header;
